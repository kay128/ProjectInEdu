package book.member.action;

import java.util.Scanner;

public interface Action {
	public void execute(Scanner sc)throws Exception;
}
